#ifndef _XT_GRADM_H
#define _XT_GRADM_H

struct xt_gradm_mtinfo {
	__u16 flags;
	__u16 invflags;
};

#endif
